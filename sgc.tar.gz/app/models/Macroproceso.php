<?php 
class Macroproceso extends Eloquent { //Todos los modelos deben extender la clase Eloquent
    protected $table = 'macroproceso';
}
?>
