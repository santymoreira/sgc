<html>
	<body>
	@section('sidebar')
		Gestión de Empleados
	@show

	<div class="container">
		@yield('content')
	</div>
	</body>
</html>