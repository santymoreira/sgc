
<img src="{{ asset('images/example.drawIndicator.png'); }}"/>





