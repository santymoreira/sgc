<!doctype html>
<html>
<head>
</head>
<body>
        
          @foreach($empleados as $empleado)

{{ $empleado->CI }} </br>
 {{ $empleado->NOMBRES }} 

 @endforeach
 </tbody>
 </table>

   </div>
 </body>

  </head>
  </html>

