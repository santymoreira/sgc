             
        //Enlaces a los macroprocesos de las Escuelas

                function PotenInvest()
                { 
                    location.href = "PotenInves";
                }
                  function AcredCarr()
                { 
                    location.href = "AcredCarr";
                }
                function AumenSatis()
                { 
                    location.href = "AumentarSatis";
                }
               function FortInterA()
                { 
                    location.href = "FortaInterApre";
                }
                function ImpleSgc()
                { 
                    location.href = "ImpleSgc";
                }
             function PoteInnov()
                { 
                    location.href = "PotenInnov";
                }
            function ImpleMcontemp()
                { 
                    location.href = "ImpleModContem";
                }
             function DesaCent()
                { 
                    location.href = "DesarrCentrosApoyo";
                }
            function PromProyec()
            {
                  location.href = "PromvProyecSoc";   
            }
            function FortaRRHH()
            {
                  location.href = "FortaCapRRHH";   
            }
            function MejorarClima()
            {
                  location.href = "MejorarClimaLab";   
            } 
            function PromoCoope()
            {
                  location.href = "PromoCoop";   
            }
            function OptiRecursos()
            {
                  location.href = "OptimiRecu";   
            }
            function obtener_finan()
            {
                  location.href = "ObtenerFinan";   
            }