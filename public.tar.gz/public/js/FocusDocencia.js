			
				
			//Cambios de imágenes de procesos de acuerdo a los responsables azul(entradas) rojo(salidas)

			function ImgAzulEstatuto()
			{
				document.getElementById('afeg013').src='../images/ProcesosEscuelas/afeg01-03_azulEst.png';
			}	
			function BackAzulEstatuto()
			{
				document.getElementById('afeg013').src='../images/ProcesosEscuelas/afeg01-03.png';
			}
			function ImgRojoNoId()
			{
				document.getElementById('afeg012').src='../images/ProcesosEscuelas/afeg01-02rojoNoId.png';
			}
			function BackRojoNoId()
			{
				document.getElementById('afeg012').src='../images/ProcesosEscuelas/afeg01-02.png';
			}