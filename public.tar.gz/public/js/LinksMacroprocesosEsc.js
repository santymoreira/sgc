               
        //Enlaces a los macroprocesos de las Escuelas

                function GestionAdmin()
                { 
                    location.href = "M_Administrativa";
                }
               function GestionAcademica()
                {
                    location.href = "M_Academica";
                }
               function Docencia()
                {
                    location.href = "M_Docencia";
                } 
                function Investigacion()
                {
                    location.href = "M_Investigacion";
                }
                function Vinculacion()
                {
                    location.href = "M_Vinculacion";
                }
                function Asistencia()
                {
                    location.href = "M_Asistencia";
                }
                function Mantenimiento()
                {
                    location.href = "M_Mantenimiento"
                }