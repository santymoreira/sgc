function ImgAzulReglamentoAc()
				{
					document.getElementById('afeg066').src='../images/ProcesosEscuelas/afeg06-06_ azul.png';
				}
				function BackAzulReglamentoAc()
				{
					document.getElementById('afeg066').src='../images/ProcesosEscuelas/afeg06-06.png';
				}
				function ImgAzulReglamentoInt()
				{
					document.getElementById('afeg061').src='../images/ProcesosEscuelas/afeg06-01_azul.png';
					document.getElementById('afeg062').src='../images/ProcesosEscuelas/afeg06-02_azul.png';
					document.getElementById('afeg063').src='../images/ProcesosEscuelas/afeg06-03_azul.png';
				}
				function BackAzulReglamentoInt()
				{
					document.getElementById('afeg061').src='../images/ProcesosEscuelas/afeg06-01.png';
					document.getElementById('afeg062').src='../images/ProcesosEscuelas/afeg06-02.png';
					document.getElementById('afeg063').src='../images/ProcesosEscuelas/afeg06-03.png';
				}
				function ImgAzulNoIdExt()
				{
					document.getElementById('afeg065').src='../images/ProcesosEscuelas/afeg06-05_azul.png';
					document.getElementById('afeg067').src='../images/ProcesosEscuelas/afeg06-07_azul.png';
					document.getElementById('afeg068').src='../images/ProcesosEscuelas/afeg06-08_azul.png';
					document.getElementById('afeg0612').src='../images/ProcesosEscuelas/afeg06-12_azul.png';
				}
				function BackAzulNoIdExt()
				{
					document.getElementById('afeg065').src='../images/ProcesosEscuelas/afeg06-05.png';
					document.getElementById('afeg067').src='../images/ProcesosEscuelas/afeg06-07.png';
					document.getElementById('afeg068').src='../images/ProcesosEscuelas/afeg06-08.png';
					document.getElementById('afeg0612').src='../images/ProcesosEscuelas/afeg06-12.png';
				}
				function ImgAzulNoIdInt()
				{
					document.getElementById('afeg064').src='../images/ProcesosEscuelas/afeg06-04_azul.png';
					document.getElementById('afeg068').src='../images/ProcesosEscuelas/afeg06-08_azul.png';
					document.getElementById('afeg069').src='../images/ProcesosEscuelas/afeg06-09_azul.png';
					document.getElementById('afeg0612').src='../images/ProcesosEscuelas/afeg06-12_azul.png';
				}
				function BackAzulNoIdInt()
				{
					document.getElementById('afeg064').src='../images/ProcesosEscuelas/afeg06-04.png';
					document.getElementById('afeg068').src='../images/ProcesosEscuelas/afeg06-08.png';
					document.getElementById('afeg069').src='../images/ProcesosEscuelas/afeg06-09.png';
					document.getElementById('afeg0612').src='../images/ProcesosEscuelas/afeg06-12.png';
				}
				function ImgRojoRegimen()
				{
					document.getElementById('afeg064').src='../images/ProcesosEscuelas/afeg06-04_rojo.png';
					document.getElementById('afeg065').src='../images/ProcesosEscuelas/afeg06-05_rojo.png';
					document.getElementById('afeg066').src='../images/ProcesosEscuelas/afeg06-06_rojo.png';
				}
				function BackRojoRegimen()
				{
					document.getElementById('afeg064').src='../images/ProcesosEscuelas/afeg06-04.png';
					document.getElementById('afeg065').src='../images/ProcesosEscuelas/afeg06-05.png';
					document.getElementById('afeg066').src='../images/ProcesosEscuelas/afeg06-06.png';
				}
				function ImgRojoReglamento()
				{
					document.getElementById('afeg061').src='../images/ProcesosEscuelas/afeg06-01_rojo.png';
					document.getElementById('afeg063').src='../images/ProcesosEscuelas/afeg06-03_rojo.png';
					document.getElementById('afeg068').src='../images/ProcesosEscuelas/afeg06-08_rojo.png';
					document.getElementById('afeg069').src='../images/ProcesosEscuelas/afeg06-09_rojo.png';
					document.getElementById('afeg0612').src='../images/ProcesosEscuelas/afeg06-12_rojo.png';
				}
				function BackRojoReglamento()
				{
					document.getElementById('afeg061').src='../images/ProcesosEscuelas/afeg06-01.png';
					document.getElementById('afeg063').src='../images/ProcesosEscuelas/afeg06-03.png';
					document.getElementById('afeg068').src='../images/ProcesosEscuelas/afeg06-08.png';
					document.getElementById('afeg069').src='../images/ProcesosEscuelas/afeg06-09.png';
					document.getElementById('afeg0612').src='../images/ProcesosEscuelas/afeg06-12.png';
				}
				function ImgRojoNoIdInt()
				{
					document.getElementById('afeg0611').src='../images/ProcesosEscuelas/afeg06-11_rojo.png';
				}
				function BackRojoNoIdInt()
				{
					document.getElementById('afeg0611').src='../images/ProcesosEscuelas/afeg06-11.png';
				}
				function ImgRojoCEADESA()
				{
					document.getElementById('afeg062').src='../images/ProcesosEscuelas/afeg06-02_rojo.png';
					document.getElementById('afeg064').src='../images/ProcesosEscuelas/afeg06-04_rojo.png';
				}
				function BackRojoCEADESA()
				{
					document.getElementById('afeg062').src='../images/ProcesosEscuelas/afeg06-02.png';
					document.getElementById('afeg064').src='../images/ProcesosEscuelas/afeg06-04.png';
				}