$(document).ready(function() {
   $('#gestionadmin').mouseenter(function() {
       $(this).animate({
           
           height: '+=5px',
           width:'+=15px'
            },5);
   });
   $('#gestionadmin').mouseleave(function() {
       $(this).animate({
           
           height: '-=5px',
           width:'-=15px'
       },5); 
   });
   $('#gestionacad').mouseenter(function() {
       $(this).animate({
           
           height: '+=5px',
           width:'+=15px'
            },5);
   });
   $('#gestionacad').mouseleave(function() {
       $(this).animate({
           
           height: '-=5px',
           width:'-=15px'
       },5); 
   }); 
     $('#docencia').mouseenter(function() {
       $(this).animate({
           
           height: '+=5px',
           width:'+=15px'
            },5);
   });
   $('#docencia').mouseleave(function() {
       $(this).animate({
           
           height: '-=5px',
           width:'-=15px'
       },5); 
   });
    $('#investigacion').mouseenter(function() {
       $(this).animate({
           
           height: '+=5px',
           width:'+=15px'
            },5);
   });
   $('#investigacion').mouseleave(function() {
       $(this).animate({
           
           height: '-=5px',
           width:'-=15px'
       },5); 
   });
   $('#vinculacion').mouseenter(function() {
       $(this).animate({
           
           height: '+=5px',
           width:'+=15px'
            },5);
   });
   $('#vinculacion').mouseleave(function() {
       $(this).animate({
           
           height: '-=5px',
           width:'-=15px'
       },5); 
   });
    $('#asistencia').mouseenter(function() {
       $(this).animate({
           
           height: '+=5px',
           width:'+=15px'
            },5);
   });
   $('#asistencia').mouseleave(function() {
       $(this).animate({
           
           height: '-=5px',
           width:'-=15px'
       },5); 
   });
    $('#mantenimiento').mouseenter(function() {
       $(this).animate({
           
           height: '+=5px',
           width:'+=15px'
            },5);
   });
   $('#mantenimiento').mouseleave(function() {
       $(this).animate({
           
          height: '-=5px',
           width:'-=15px'
       },5); 
   });
   //Macroprocesos FADE
    $('#administrativa').mouseenter(function() {
       $(this).animate({
           
           height: '+=5px',
           width:'+=15px'
            },5);
   });
   $('#administrativa').mouseleave(function() {
       $(this).animate({
           
          height: '-=5px',
           width:'-=15px'
       },5); 
   });
   $('#academica').mouseenter(function() {
       $(this).animate({
           
           height: '+=5px',
           width:'+=15px'
            },5);
   });
   $('#academica').mouseleave(function() {
       $(this).animate({
           
          height: '-=5px',
           width:'-=15px'
       },5); 
   });
   $('#calidad').mouseenter(function() {
       $(this).animate({
           
           height: '+=5px',
           width:'+=15px'
            },5);
   });
   $('#calidad').mouseleave(function() {
       $(this).animate({
           
          height: '-=5px',
           width:'-=15px'
       },5); 
   });
   $('#academico').mouseenter(function() {
       $(this).animate({
           
           height: '+=5px',
           width:'+=15px'
            },5);
   });
   $('#academico').mouseleave(function() {
       $(this).animate({
           
          height: '-=5px',
           width:'-=15px'
       },5); 
   });
   $('#financiero').mouseenter(function() {
       $(this).animate({
           
           height: '+=5px',
           width:'+=15px'
            },5);
   });
   $('#financiero').mouseleave(function() {
       $(this).animate({
           
          height: '-=5px',
           width:'-=15px'
       },5); 
   });
   $('#transporte').mouseenter(function() {
       $(this).animate({
           
           height: '+=5px',
           width:'+=15px'
            },5);
   });
   $('#transporte').mouseleave(function() {
       $(this).animate({
           
          height: '-=5px',
           width:'-=15px'
       },5); 
   });
   $('#informatico').mouseenter(function() {
       $(this).animate({
           
           height: '+=5px',
           width:'+=15px'
            },5);
   });
   $('#informatico').mouseleave(function() {
       $(this).animate({
           
          height: '-=5px',
           width:'-=15px'
       },5); 
   });
//   Objetos internos

//       Efecto a los códigos del proceso 
    $('#afeg04_1').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_1').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg04_2').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_2').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg04_3').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_3').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg04_4').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_4').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg04_5').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_5').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg04_6').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_6').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg04_7').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_7').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
  $('#afeg04_8').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_8').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_9').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_9').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_10').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_10').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_11').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_11').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_12').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_12').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_13').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_13').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_14').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_14').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_15').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_15').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_16').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_16').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_17').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_17').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_18').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_18').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_19').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_19').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_20').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_20').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_21').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_21').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_22').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_22').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_23').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_23').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_24').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_24').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_25').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_25').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg04_26').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg04_26').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   //codigos proceso gestion academica
    $('#afeg05_1').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg05_1').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg05_2').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg05_2').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg05_3').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg05_3').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg05_4').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg05_4').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg05_5').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg05_5').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg05_6').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg05_6').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg05_7').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg05_7').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg05_8').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg05_8').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg05_9').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg05_9').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   //codigos procesos docencia
  $('#afeg01_1').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg01_1').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
  $('#afeg01_2').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg01_2').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
  $('#afeg01_3').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg01_3').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
  $('#afeg01_4').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg01_4').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg01_5').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg01_5').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg01_6').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg01_6').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   //codigos proceso investigacion 
  $('#afeg02_1').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg02_1').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
  $('#afeg02_2').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg02_2').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg02_3').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg02_3').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   
   //codigos procesos vinculacion
   $('#afeg03_1').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg03_1').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
  $('#afeg03_2').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg03_2').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg03_3').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg03_3').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   //codigos proceso mantenimiento 
   $('#afeg07_1').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg07_1').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg07_2').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg07_2').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg07_3').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg07_3').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg07_4').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg07_4').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg07_5').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg07_5').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg07_6').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg07_6').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg07_7').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg07_7').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg07_8').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg07_8').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg07_9').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg07_9').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg07_10').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg07_10').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg07_11').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg07_11').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   //procesos codigos docencia
   $('#afeg06_1').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_1').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_2').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_2').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_3').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_3').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_4').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_4').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_5').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_5').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_6').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_6').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_7').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_7').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_8').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_8').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_9').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_9').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_10').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_10').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_11').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_11').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_12').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_12').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_13').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_13').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_14').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_14').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_15').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_15').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_16').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_16').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_17').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_17').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_18').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_18').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_19').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_19').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_20').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_20').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_21').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_21').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_22').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_22').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_23').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_23').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_24').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_24').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_25').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_25').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_26').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_26').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_27').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_27').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_28').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_28').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_29').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_29').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   //codigos Apoyo Academico
   $('#afeag08_1').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_1').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag08_2').mouseenter(function() {
       $(this).animate({
           
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_2').mouseleave(function() {
       $(this).animate({
           
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag08_3').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_3').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_4').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_4').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag08_5').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_5').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_6').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_6').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_7').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_7').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_8').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_8').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_9').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_9').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_10').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_10').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_11').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_11').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_12').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_12').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_13').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_13').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_14').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_14').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_15').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_15').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_16').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_16').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_17').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_17').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_18').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_18').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_19').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_19').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_20').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_20').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_21').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_21').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_22').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_22').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_23').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_23').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_24').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_24').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_25').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_25').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_26').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_26').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_27').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_27').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_28').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_28').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeag08_29').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag08_29').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_01').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_01').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_02').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_02').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_03').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_03').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_04').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_04').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_05').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_05').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_06').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_06').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_07').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_07').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_08').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_08').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_09').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_09').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_10').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_10').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_11').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_11').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_12').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_12').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_13').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_13').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_14').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_14').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_15').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_15').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_16').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_16').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_17').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_17').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_18').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_18').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_19').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_19').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_20').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_20').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_21').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_21').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_22').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_22').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_23').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_23').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea12_24').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea12_24').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   //Codigos macroFADE Calidad
  $('#afeg06_01').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_01').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_02').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_02').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_03').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_03').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_04').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_04').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_05').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_05').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_06').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_06').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_07').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_07').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_08').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_08').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_09').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_09').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afeg06_10').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_10').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_11').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_11').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_12').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_12').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_13').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_13').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_14').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_14').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_15').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_15').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_16').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_16').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_17').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_17').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_18').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_18').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_19').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_19').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_20').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_20').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_21').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_21').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_22').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_22').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_23').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_23').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_24').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_24').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_25').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_25').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_26').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_26').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_27').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_27').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_28').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_28').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeg06_29').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeg06_29').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   //Macroprocesos Transporte FADE
   $('#afea11_01').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_01').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
    $('#afea11_02').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_02').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_03').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_03').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_04').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_04').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_05').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_05').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_06').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_06').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_07').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_07').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_08').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_08').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_09').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_09').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_10').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_10').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_11').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_11').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_12').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_12').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_13').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_13').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_14').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_14').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_15').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_15').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_16').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_16').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_17').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_17').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afea11_18').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afea11_18').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   //Codigos procesos Financiero FADE
    $('#afeag09_1').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_1').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_2').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_2').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_3').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_3').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_4').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_4').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_5').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_5').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_6').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_6').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_7').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_7').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_8').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_8').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_9').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_9').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_10').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_10').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_11').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_11').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_12').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_12').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_13').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_13').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_14').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_14').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_15').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_15').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_16').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_16').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   $('#afeag09_17').mouseenter(function() {
       $(this).animate({
           height: '+=3px',
           width:'+=3px'
            },5);
   });
   $('#afeag09_17').mouseleave(function() {
       $(this).animate({
           height: '-=3px',
           width:'-=3px'
       },5); 
   });
   //sombra en las imagenes de procesos gestion administrativa
   $('#afeg041').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg041').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg042').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg042').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg043').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg043').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg044').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg044').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg045').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg045').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg046').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg046').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg047').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg047').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg048').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg048').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg049').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg049').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0410').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0410').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0411').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0411').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0412').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0412').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0413').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0413').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0414').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0414').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0415').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0415').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0416').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0416').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0417').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0417').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0418').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0418').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0419').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0419').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0420').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0420').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0421').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0421').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0422').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0422').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0423').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0423').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0424').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0424').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0425').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0425').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg0426').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0426').mouseleave(function() {
       $(this).css('border',0); 
   });
    //procesos gestion academica
    $('#afeg051').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg051').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg052').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg052').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg053').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg053').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg054').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg054').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg055').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg055').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg056').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg056').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg057').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg057').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg058').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg058').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg059').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg059').mouseleave(function() {
       $(this).css('border',0); 
   });
   //Procesos Docencia
   $('#afeg011').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg011').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg012').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg012').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg013').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg013').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg014').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg014').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg015').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg015').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg016').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg016').mouseleave(function() {
       $(this).css('border',0); 
   });
   //procesos e investigacion
    $('#afeg021').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg021').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg022').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg022').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg023').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg023').mouseleave(function() {
       $(this).css('border',0); 
   });
   //procesos de vinculacion
   $('#afeg031').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg031').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg032').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg032').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg033').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg033').mouseleave(function() {
       $(this).css('border',0); 
   });
   //procesos mantenimiento
   $('#afeg071').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg071').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg072').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg072').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg073').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg073').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg074').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg074').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg075').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg075').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg076').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg076').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg077').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg077').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg078').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg078').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg079').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg079').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0710').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0710').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0711').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0711').mouseleave(function() {
       $(this).css('border',0); 
   });
   //procesos grandes docencia 
  $('#afeg061').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg061').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg062').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg062').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg063').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg063').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeg064').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg064').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg065').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg065').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg066').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg066').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg067').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg067').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg068').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg068').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg069').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg069').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0610').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0610').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0611').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0611').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0612').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0612').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0613').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0613').mouseleave(function() {
       $(this).css('border',0); 
   }); 
    $('#afeg0614').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0614').mouseleave(function() {
       $(this).css('border',0); 
   }); 
    $('#afeg0615').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0615').mouseleave(function() {
       $(this).css('border',0); 
   }); 
    $('#afeg0616').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0616').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0617').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0617').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0618').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0618').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0619').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0619').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0620').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0620').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0621').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0621').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0622').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0622').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0623').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0623').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0624').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0624').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0625').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0625').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0626').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0626').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0627').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0627').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0628').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0628').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeg0629').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeg0629').mouseleave(function() {
       $(this).css('border',0); 
   });
   //procesos Apoyo Academico
   $('#afeag081').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag081').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag082').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag082').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag083').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag083').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag084').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag084').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag085').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag085').mouseleave(function() {
       $(this).css('border',0); 
   });
  $('#afeag086').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag086').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag087').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag087').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag088').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag088').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag089').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag089').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0810').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0810').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0811').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0811').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0812').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0812').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0813').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0813').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0814').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0814').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0815').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0815').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0816').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0816').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0817').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0817').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0818').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0818').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0819').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0819').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0820').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0820').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0821').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0821').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0822').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0822').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0823').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0823').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0824').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0824').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0825').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0825').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0826').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0826').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0827').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0827').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0828').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0828').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afeag0829').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0829').mouseleave(function() {
       $(this).css('border',0); 
   });
   
   //proceso MACROFADE Informatico
   
    $('#afea121').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea121').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea122').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea122').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea123').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea123').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea124').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea124').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea125').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea125').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea126').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea126').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea127').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea127').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea128').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea128').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea129').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea129').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1210').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1210').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1211').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1211').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1212').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1212').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1213').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1213').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1214').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1214').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1215').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1215').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1216').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1216').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1217').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1217').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1218').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1218').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1219').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1219').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1220').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1220').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1221').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1221').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1222').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1222').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1223').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1223').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afea1224').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1224').mouseleave(function() {
       $(this).css('border',0); 
   });
   
   //Procesos Transporte FADE
    $('#afea111').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea111').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea112').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea112').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea113').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea113').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea114').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea114').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea115').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea115').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea116').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea116').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea117').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea117').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea118').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea118').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea119').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea119').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea1110').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1110').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea1111').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1111').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea1112').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1112').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea1113').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1113').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea1114').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1114').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea1115').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1115').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea1116').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1116').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea1117').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1117').mouseleave(function() {
       $(this).css('border',0); 
   });
   $('#afea1118').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afea1118').mouseleave(function() {
       $(this).css('border',0); 
   });
   //Códigos procesos Financiero
   $('#afeag091').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag091').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag092').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag092').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag093').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag093').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag094').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag094').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag095').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag095').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag096').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag096').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag097').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag097').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag098').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag098').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag099').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag099').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag0910').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0910').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag0911').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0911').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag0912').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0912').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag0913').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0913').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag0914').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0914').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag0915').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0915').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag0916').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0916').mouseleave(function() {
       $(this).css('border',0); 
   });
    $('#afeag0917').mouseenter(function() {
       $(this).css('border','1px solid #0066CC');
   });
      $('#afeag0917').mouseleave(function() {
       $(this).css('border',0); 
   });
//    Efectos de move a los procesos y a
//   $('#afeg041').mouseenter(function() {
//       $(this).css('margin-top','-3px');
//   });
//   $('#afeg041').mouseleave(function() {
//       $(this).css('margin-top','+0px');
//   });
//   
   
});