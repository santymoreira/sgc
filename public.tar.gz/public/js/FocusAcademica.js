				

	
			//Cambios de imágenes de procesos de acuerdo a los responsables azul(entradas) rojo(salidas)

				function ImgAzulDecanato()
				{
					document.getElementById('afeg051').src='../images/ProcesosEscuelas/afeg05-01_azul.png';
					document.getElementById('afeg055').src='../images/ProcesosEscuelas/afeg05-05_azul.png';
				}
				function BackAzulDecanato()
				{
					document.getElementById('afeg051').src='../images/ProcesosEscuelas/afeg05-01.png';
					document.getElementById('afeg055').src='../images/ProcesosEscuelas/afeg05-05.png';
				}
				function ImgAzulCIADES()
				{
					document.getElementById('afeg051').src='../images/ProcesosEscuelas/afeg05-01_azulDE.png';
					document.getElementById('afeg052').src='../images/ProcesosEscuelas/afeg05-02_azulDE.png';
					document.getElementById('afeg057').src='../images/ProcesosEscuelas/afeg05-07_azulDE.png';
					document.getElementById('afeg058').src='../images/ProcesosEscuelas/afeg05-08_azulDE.png';
				}
				function BackAzulCIADES()
				{
					document.getElementById('afeg051').src='../images/ProcesosEscuelas/afeg05-01.png';
					document.getElementById('afeg052').src='../images/ProcesosEscuelas/afeg05-02.png';
					document.getElementById('afeg057').src='../images/ProcesosEscuelas/afeg05-07.png';
					document.getElementById('afeg058').src='../images/ProcesosEscuelas/afeg05-08.png';
				}
				function ImgAzulComision()
				{
					document.getElementById('afeg054').src='../images/ProcesosEscuelas/afeg05-04_azulPlanificacion.png';
				}
				function BackAzulComision()
				{
					document.getElementById('afeg054').src='../images/ProcesosEscuelas/afeg05-04.png';
				}
				function ImgAzulNoId()
				{
					document.getElementById('afeg059').src='../images/ProcesosEscuelas/afeg05-09_azulNoId.png';
				}
				function BackAzulNoId()
				{
					document.getElementById('afeg059').src='../images/ProcesosEscuelas/afeg05-09.png';
				}
				function ImgAzulEstatuto()
				{
					document.getElementById('afeg051').src='../images/ProcesosEscuelas/afeg05-01_azulEP.png';
					document.getElementById('afeg055').src='../images/ProcesosEscuelas/afeg05-05_azulEP.png';
					document.getElementById('afeg056').src='../images/ProcesosEscuelas/afeg05-06_azulEP.png';
				}
				function BackAzulEstatuto()
				{
					document.getElementById('afeg051').src='../images/ProcesosEscuelas/afeg05-01.png';
					document.getElementById('afeg055').src='../images/ProcesosEscuelas/afeg05-05.png';
					document.getElementById('afeg056').src='../images/ProcesosEscuelas/afeg05-06.png';
				}
				function ImgRojoCIADES()
				{
					document.getElementById('afeg052').src='../images/ProcesosEscuelas/afeg05-02_rojoCiades.png';
				}
				function BackRojoCIADES()
				{
					document.getElementById('afeg052').src='../images/ProcesosEscuelas/afeg05-02.png';
				}
				function ImgRojoComision()
				{
					document.getElementById('afeg059').src='../images/ProcesosEscuelas/afeg05-09_rojoPlanificacion.png';
				}
				function BackRojoComision()
				{
					document.getElementById('afeg059').src='../images/ProcesosEscuelas/afeg05-09.png';
				}
				function ImgRojoNoId()
				{
					document.getElementById('afeg054').src='../images/ProcesosEscuelas/afeg05-04_rojoNoId.png';
					document.getElementById('afeg056').src='../images/ProcesosEscuelas/afeg05-06_rojoNoId.png';	
				}
				function BackRojoNoId()
				{
					document.getElementById('afeg054').src='../images/ProcesosEscuelas/afeg05-04.png';
					document.getElementById('afeg056').src='../images/ProcesosEscuelas/afeg05-06.png';
				} 