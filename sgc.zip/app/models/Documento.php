<?php 
class Documento extends Eloquent { //Todos los modelos deben extender la clase Eloquent
    protected $table = 'documento';
}
?>
