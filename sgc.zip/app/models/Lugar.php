<?php 
class Lugar extends Eloquent { //Todos los modelos deben extender la clase Eloquent
    protected $table = 'lugar';
}
?>
