<?php 
class Indicador extends Eloquent { //Todos los modelos deben extender la clase Eloquent
    protected $table = 'indicador';
}
?>
