<?php 
class TipoMacroproceso extends Eloquent { //Todos los modelos deben extender la clase Eloquent
    protected $table = 'tipo_macroproceso';
}
?>
