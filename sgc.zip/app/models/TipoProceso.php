<?php 
class TipoProceso extends Eloquent { //Todos los modelos deben extender la clase Eloquent
    protected $table = 'tipo_proceso';
}
?>
