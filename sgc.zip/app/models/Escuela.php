<?php 
class Escuela extends Eloquent { //Todos los modelos deben extender la clase Eloquent
    protected $table = 'escuela';
}
?>