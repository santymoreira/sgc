<?php 
// se debe indicar en donde esta la interfaz a implementar
use Illuminate\Auth\UserInterface;

 
Class Empleado extends Eloquent implements UserInterface{

     //public static $timestamps = false;
    public $timestamps = false;
    protected $table = 'empleado';
    protected $fillable = array('COD_EMPLEADO','CI','NOMBRES','SEXO','EMAIL','CELULAR','CONVENCIONAL','password');
 

    // este metodo se debe implementar por la interfaz
    public function getAuthIdentifier()
    {
        return $this->getKey();
    }
    
    //este metodo se debe implementar por la interfaz
    // y sirve para obtener la clave al momento de validar el inicio de sesión 
    public function getAuthPassword()
    {
        return $this->password;
    }
public function getRememberToken() {
return 0;
}

public function setRememberToken($token) {
return 0;
}

public function getRememberTokenName()
{
return 0;
}
    
}
?>