@extends('layouts.master')
 
@section('sidebar')
     @parent
     Lista de empleados
@stop
 
@section('content')
        <h1>
  Empleados
      
    
  
</h1>
        {{ HTML::link('empleados/nuevo', 'Crear Empleado'); }}
 
<ul>
  @foreach($empleados as $empleado)
           <li>
    {{ HTML::link( 'empleados/'.$empleado->COD_EMPLEADO , $empleado->NOMBRES.' '.$empleado->SEXO ) }}
      
  </li>
          @endforeach
  </ul>



@stop