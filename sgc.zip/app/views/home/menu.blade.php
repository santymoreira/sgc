@extends('home/welcome')
                        @section('buttons')

                                  <div id="menu">
<ul>
  <li class="nivel1"><a href="#" class="nivel1">SGC</a>
	<ul class="uno">
                <li><a href="Vista/MacroFADE.php">FADE</a></li>
            	<li><a href="#">Gestion de Transporte</a></li>
                <li><a href="#">Administracion de Empresas</a></li>
                <li><a href="#">Marketing</a></li>
                <li><a href="SGC.php">Contabilidad y Auditoria</a></li>
                <li><a href="#">Educacion a Distancia</a></li>
                <li><a href="#">Comercio Exterior</a></li>
                <li><a href="#">Finanzas</a></li>
	</ul>
  </li>
  <li class="nivel1"><a href="#" class="nivel1">BSC</a>
	<ul class="dos">
		<li><a href="#">FADE</a></li>
		<li><a href="#">Gestion de Transporte</a></li>
                <li><a href="#">Administracion de Empresas</a></li>
                <li><a href="#">Marketing</a></li>
                <li><a href="#">Contabilidad y Auditoria</a></li>
                <li><a href="#">Educacion a Distancia</a></li>
                <li><a href="#">Comercio Exterior</a></li>
                <li><a href="#">Finanzas</a></li>
	</ul>
</li>
  
</ul>
</div>-

                        @stop