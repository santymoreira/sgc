<!doctype html>
<html>
<head>
	{{ HTML::script('js/smoke.js'); }}
	{{ HTML::script('js/jquery-1.8.2.min.js'); }}
	{{ HTML::script('js/ResponsiveTabs.js'); }}
	{{ HTML::script('js/login.js'); }}
	{{ HTML::script('js/opciones_presentacion.js'); }}

	{{ HTML::style('css/smoke.css'); }}
	{{ HTML::style('css/estilo.css'); }}
	<!--        estilo cabecera-->
	{{ HTML::style('css/easy-responsive-tabs.css'); }}
	{{ HTML::style('css/floatbox.css'); }}
	{{ HTML::style('css/style.css'); }}
	{{ HTML::style('css/kik.css'); }}
	{{ HTML::style('css/menu22.css'); }}
	<!--        estilo menu principal-->

@if (Session::has('mensaje_login'))
<span>{{ Session::get('mensaje_login') }}</span>
@endif
   
  

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <title>Sistema de Gestión de Calidad</title>
   </head>
   <body>

   		<div id="main">
        <div class="sheet">
            <div class="sheet-body">
                 <div class="header">
                    <div class="header-center">        
                        <a href="DatosPersonales/index.php"  rel="floatbox">
                             <div id="apDiv8"><img src="images/fotoreal.png" style="border: solid 5px #00003d; cursor: pointer;"  width="92" height="92"></div>

                              <?php 
                              if ( Auth::check()): ?>
                                <div id="apDiv8"><img src="images/logoIndex.png" style="border: solid 5px #00003d; cursor: pointer;"  width="92" height="92"></div>
                               <?php endif; ?>


                           
                        </a>        
                        <div class="header-png"><img src="images/header.png" width="1134" height="137" />   

                         @section('options')
                    		<div id="menu">
								<ul>
  									<li class="nivel1"><a href="#" class="nivel1">SGC</a>
										<ul class="uno">
                							<li><a href="Vista/MacroFADE.php">FADE</a></li>
            								<li><a href="#">Gestion de Transporte</a></li>
                							<li><a href="#">Administracion de Empresas</a></li>
                							<li><a href="#">Marketing</a></li>
                							<li><a href="SGC.php">Contabilidad y Auditoria</a></li>
                							<li><a href="#">Educacion a Distancia</a></li>
               						 		<li><a href="#">Comercio Exterior</a></li>
                							<li><a href="#">Finanzas</a></li>
										</ul>
  									</li>
  									<li class="nivel1"><a href="#" class="nivel1">BSC</a>
										<ul class="dos">
											<li><a href="#">FADE</a></li>
											<li><a href="#">Gestion de Transporte</a></li>
                							<li><a href="#">Administracion de Empresas</a></li>
                							<li><a href="#">Marketing</a></li>
                							<li><a href="#">Contabilidad y Auditoria</a></li>
                							<li><a href="#">Educacion a Distancia</a></li>
                							<li><a href="#">Comercio Exterior</a></li>
                							<li><a href="#">Finanzas</a></li>
										</ul>
									</li>
  								</ul>
							</div>
                         @show

                        </div>
                    </div>

                    @section('login')

                    <div id="container">
          				<div id="loginContainer">
                			<a href="#" id="loginButton"><img id="imgLogin" src="images/iniciar sesion.png" border=0></a>
                			<div style="clear:both"></div>
                			<div id="loginBox">   
                    			<!--<form id="loginForm">-->
                          {{ Form::open(array('url' => 'layout','id'=>'loginForm')) }}
                        			<fieldset id="body">
                            			<fieldset>
                                			<label for="email">Usuario</label>
                                       {{Form::text('username');}}
                                		<!--	<input type="text" name="username" id="username" />-->
                            			</fieldset>
                            			<fieldset>
                                			<label for="password">Contraseña</label>
                                      {{Form::password('password');}}
                                			<!--<input type="password" name="password" id="password" />-->
                            			</fieldset>
                                  {{Form::submit('Iniciar Sesión', ['id' => 'login'])}}
                            			<!--<input type="button" id="login" value="Iniciar Sesión" />-->
                        			</fieldset>
                        			<span><a href="#">Registro SGC</a></span>
                    			<!--</form>-->
                          {{ Form::close() }}
                			</div>
            			</div>
          			</div>

                    @show

                    <div id="apDiv6"><img src="images/SGCheader.png" width="426"></div> 
                 </div>

                 @section('body')

                 @show

                @yield('content')

   </body>
</html>