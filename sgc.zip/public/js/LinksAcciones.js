             
        //Enlaces a los macroprocesos de las Escuelas

                function PotenInvest()
                { 
                    location.href = "PotenInves";
                }
                  function AcredCarr()
                { 
                    location.href = "AcredCarr";
                }
                function AumenSatis()
                { 
                    location.href = "AumentarSatis";
                }
               function FortInterA()
                { 
                    location.href = "FortaInterApre";
                }
                function ImpleSgc()
                { 
                    location.href = "ImpleSgc";
                }
             function PoteInnov()
                { 
                    location.href = "PotenInnov";
                }
            function PotenVinSoc()
                { 
                    location.href = "PotenVincSociedad";
                }
             function DesaCent()
                { 
                    location.href = "DesarrCentrosApoyo";
                }
            function ImpleGproce()
            {
                  location.href = "ImplenGestionProc";   
            }
            function FortaCapDocentes()
            {
                  location.href = "FortaCapDoc";   
            }
            function MejorarClima()
            {
                  location.href = "MejorarClimaLab";   
            } 
            function PromoCoope()
            {
                  location.href = "PromoCoop";   
            }
            function OptiRecursos()
            {
                  location.href = "OptimiRecu";   
            }
            function obtener_finan()
            {
                  location.href = "ObtenerFinan";   
            }