                function Administrativa()
                { 
                     location.href = "MF_Administrativa";
                }
                function Academica()
                {
                     location.href = "MF_Academica";
                }
                function Calidad()
                {
                   location.href = "MF_Calidad";
                }
                function Docencia(){ 
                           location.href = "MF_Docencia";
                     }
                function Investigacion(){ 
                           location.href = "MF_Investigacion";
                     }
                function Vinculacion(){ 
                           location.href = "MF_Vinculacion";
                     }     
                function Asistenca()
                {
                   location.href = "MF_Asistencia";
                }
                function Academico()
                {
                    location.href = "MF_Academico";
                }
                 function Financiero()
                {
                   location.href = "MF_Financiero";
                }
                 function Mantenimiento()
                {
                   location.href = "MF_Mantenimiento";
                }
                 function Transporte()
                {
                   location.href = "MF_Transporte";
                }
                function Informatico()
                {
                    location.href = "MF_Informatico";
                }