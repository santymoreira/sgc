     $(document).ready(function(){
$( "#kk" ).click(function() {
  alert( "Handler for .click() called." );
});

  });