	$(document).ready(function(){
	$('#date').datepicker({
		showOn: 'both',
		buttonText: 'Selecciona una fecha',
		buttonImage: '../../images/calendar.png',
		buttonImageOnly: true,
		numberOfMonths: 2,
		maxDate: '0d',
		minDate: '-1m',
		showButtonPanel: true
	});
		$('#date1').datepicker();

      });
      $(document).ready(function(){
	$('#date').datepicker({
		showOn: 'both',
		buttonText: 'Selecciona una fecha',
		buttonImage: '../../images/calendar.png',
		buttonImageOnly: true,
		numberOfMonths: 2,
		maxDate: '0d',
		minDate: '-1m',
		showButtonPanel: true
	});
		$('#date2').datepicker();

      });
           $(function($){
    $.datepicker.regional['es'] = {
        closeText: 'Cerrar',
        prevText: '<Ant',
        nextText: 'Sig>',
        currentText: 'Hoy',
        monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
        monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
        dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
        dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
        dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
        weekHeader: 'Sm',
        dateFormat: 'yy-mm-dd',
        firstDay: 1,
        isRTL: false,
        showMonthAfterYear: false,
        yearSuffix: ''
    };
    $.datepicker.setDefaults($.datepicker.regional['es']);
});
