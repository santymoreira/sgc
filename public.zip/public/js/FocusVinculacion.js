				
//Cambios de imágenes de procesos de acuerdo a los responsables azul(entradas) rojo(salidas)

		

				function ImgAzulCoordinador()
				{
					document.getElementById('afeg031').src='../images/ProcesosEscuelas/afeg03-01_azulCoord.png';
					document.getElementById('afeg032').src='../images/ProcesosEscuelas/afeg03-02_azulCoord.png';
					document.getElementById('afeg033').src='../images/ProcesosEscuelas/afeg03-03_azulCoord.png';
				}
				function BackAzulCoordinador()
				{
					document.getElementById('afeg031').src='../images/ProcesosEscuelas/afeg03-01.png';
					document.getElementById('afeg032').src='../images/ProcesosEscuelas/afeg03-02.png';
					document.getElementById('afeg033').src='../images/ProcesosEscuelas/afeg03-03.png';
				}
			  function ImgAzulNoId()
			   {
				   document.getElementById('afeg032').src='../images/ProcesosEscuelas/afeg03-02_azulNoId.png';
			   }  	
              function BackAzulNoId()
			  {
				  document.getElementById('afeg032').src='../images/ProcesosEscuelas/afeg03-02.png';
		      } 
			  function ImgRojoCoordinador()
			  {
				  document.getElementById('afeg031').src='../images/ProcesosEscuelas/afeg03-01_rojoCoord.png';
				  document.getElementById('afeg032').src='../images/ProcesosEscuelas/afeg03-02_rojoCoord.png';
			  }
			  function BackRojoCoordinador()
			  {
  				  document.getElementById('afeg031').src='../images/ProcesosEscuelas/afeg03-01.png';
                  document.getElementById('afeg032').src='../images/ProcesosEscuelas/afeg03-02.png';
			  }