				
			//Cambios de imágenes de procesos de acuerdo a los responsables azul(entradas) rojo(salidas)

			
				function ImgAzulComision()
				{
					document.getElementById('afeg021').src='../images/ProcesosEscuelas/afeg02-01_azulPlanificacion.png';
				}
				function BackAzulComision()
				{
					document.getElementById('afeg021').src='../images/ProcesosEscuelas/afeg02-01.png';
				}
				function ImgAzulNoId()
				{
					document.getElementById('afeg021').src='../images/ProcesosEscuelas/afeg02-01_azulNoId.png';
				}
				function BackAzulNoId()
				{
					document.getElementById('afeg021').src='../images/ProcesosEscuelas/afeg02-01.png';
				}
				function ImgRojoCIADES()
				{
					document.getElementById('afeg022').src='../images/ProcesosEscuelas/afeg02-02_rojoCiades.png';
				}
				function BackRojoCIADES()
				{
					document.getElementById('afeg022').src='../images/ProcesosEscuelas/afeg02-02.png';
				}