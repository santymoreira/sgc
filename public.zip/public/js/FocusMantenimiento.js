

				function ImgAzulEstatuto()
				{
					document.getElementById('afeg071').src='../images/ProcesosEscuelas/afeg07-01_azul.png';
					document.getElementById('afeg074').src='../images/ProcesosEscuelas/afeg07-04_azul.png';
					document.getElementById('afeg075').src='../images/ProcesosEscuelas/afeg07-05_azul.png';
					document.getElementById('afeg076').src='../images/ProcesosEscuelas/afeg07-06_azul.png';
					document.getElementById('afeg078').src='../images/ProcesosEscuelas/afeg07-08_azul.png';
					document.getElementById('afeg079').src='../images/ProcesosEscuelas/afeg07-09_azul.png';
				}
				function BackAzulEstatuto()
				{
					document.getElementById('afeg071').src='../images/ProcesosEscuelas/afeg07-01.png';
					document.getElementById('afeg074').src='../images/ProcesosEscuelas/afeg07-04.png';
					document.getElementById('afeg075').src='../images/ProcesosEscuelas/afeg07-05.png';
					document.getElementById('afeg076').src='../images/ProcesosEscuelas/afeg07-06.png';
					document.getElementById('afeg078').src='../images/ProcesosEscuelas/afeg07-08.png';
					document.getElementById('afeg079').src='../images/ProcesosEscuelas/afeg07-09.png';
				}
				function ImgAzulNoIdExt()
				{
					document.getElementById('afeg0710').src='../images/ProcesosEscuelas/afeg07-10_azul.png';
				}
				function BackAzulNoIdExt()
				{
					document.getElementById('afeg0710').src='../images/ProcesosEscuelas/afeg07-10.png';
				}
				function ImgAzulReglamento()
				{
					document.getElementById('afeg073').src='../images/ProcesosEscuelas/afeg07-03_azul.png';
					document.getElementById('afeg078').src='../images/ProcesosEscuelas/afeg07-08_azul.png';
					document.getElementById('afeg079').src='../images/ProcesosEscuelas/afeg07-09_azul.png';
					document.getElementById('afeg0711').src='../images/ProcesosEscuelas/afeg07-11_azul.png';
				}
				function BackAzulReglamento()
				{
					document.getElementById('afeg073').src='../images/ProcesosEscuelas/afeg07-03.png';
					document.getElementById('afeg078').src='../images/ProcesosEscuelas/afeg07-08.png';
					document.getElementById('afeg079').src='../images/ProcesosEscuelas/afeg07-09.png';
					document.getElementById('afeg0711').src='../images/ProcesosEscuelas/afeg07-11.png';
				}
				function ImgAzulNoIdInt()
				{
					document.getElementById('afeg0710').src='../images/ProcesosEscuelas/afeg07-10_azul.png';
				}
				function BackAzulNoIdInt()
				{
					document.getElementById('afeg0710').src='../images/ProcesosEscuelas/afeg07-10.png';
				}
				function ImgRojoReglamento()
				{
					document.getElementById('afeg078').src='../images/ProcesosEscuelas/afeg07-08_rojo.png';
					document.getElementById('afeg079').src='../images/ProcesosEscuelas/afeg07-09_rojo.png';
				}
				function BackRojoReglamento()
				{
					document.getElementById('afeg078').src='../images/ProcesosEscuelas/afeg07-08.png';
					document.getElementById('afeg079').src='../images/ProcesosEscuelas/afeg07-09.png';
				}
				function ImgRojoNoId()
				{
					document.getElementById('afeg077').src='../images/ProcesosEscuelas/afeg07-07_rojo.png';
				}
				function BackRojoNoId()
				{
					document.getElementById('afeg077').src='../images/ProcesosEscuelas/afeg07-07.png';
				}