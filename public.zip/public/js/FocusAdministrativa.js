		  

			
			//Cambios de imágenes de procesos de acuerdo a los responsables azul(entradas) rojo(salidas)

		  function CambiaImagenes_Decanato()
          {
             document.getElementById('afeg041').src='../images/ProcesosEscuelas/afeg04-01_azulD.png';
             document.getElementById('afeg044').src='../images/ProcesosEscuelas/afeg04-04_azulD.png';
             document.getElementById('afeg045').src='../images/ProcesosEscuelas/afeg04-05_azulD.png';
          }
          function Back_Decanato()
          {
             document.getElementById('afeg041').src='../images/ProcesosEscuelas/afeg04-01.png';
             document.getElementById('afeg044').src='../images/ProcesosEscuelas/afeg04-04.png';
             document.getElementById('afeg045').src='../images/ProcesosEscuelas/afeg04-05.png';
          }
		  function Imagenes_Estatutos()
		  {
			 document.getElementById('afeg042').src='../images/ProcesosEscuelas/afeg04-02_azulEst.png';
			 document.getElementById('afeg043').src='../images/ProcesosEscuelas/afeg04-03_azulEst.png';
			 document.getElementById('afeg047').src='../images/ProcesosEscuelas/afeg04-07_azulEst.png';
		  }
		  function Back_Estatutos()
		  {
			 document.getElementById('afeg042').src='../images/ProcesosEscuelas/afeg04-02.png';
			 document.getElementById('afeg043').src='../images/ProcesosEscuelas/afeg04-03.png';
			 document.getElementById('afeg047').src='../images/ProcesosEscuelas/afeg04-07.png';
		   }
		   function Imagenes_NoId()
		   {
             document.getElementById('afeg045').src='../images/ProcesosEscuelas/afeg04-05_azulNoId.png';
       	   }
		      function Back_NoId()
          {
             document.getElementById('afeg045').src='../images/ProcesosEscuelas/afeg04-05.png';
          }
		function ImgRojoNoId()
		{
		     document.getElementById('afeg046').src='../images/ProcesosEscuelas/afeg04-06_rojoNoId.png';
        }
		function RojoBackNoId()
		{
		     document.getElementById('afeg046').src='../images/ProcesosEscuelas/afeg04-06.png';
		}
		function ImgRojoDecanato()
		{
		     document.getElementById('afeg041').src='../images/ProcesosEscuelas/afeg04-01_rojoD.png';
			 document.getElementById('afeg043').src='../images/ProcesosEscuelas/afeg04-03_rojoD.png';
		}
		function RojoBackDecanato()
		{
			 document.getElementById('afeg041').src='../images/ProcesosEscuelas/afeg04-01.png';
			 document.getElementById('afeg043').src='../images/ProcesosEscuelas/afeg04-03.png';
		}
		function ImgRojoComision()
		{
		 document.getElementById('afeg044').src='../images/ProcesosEscuelas/afeg04-04_rojoPlanificacion.png';
		}
		function RojoBackComision()
		{
		 document.getElementById('afeg044').src='../images/ProcesosEscuelas/afeg04-04.png';
			
		}